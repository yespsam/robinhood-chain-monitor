import { Sessions } from './auth.mjs';
import { createApplication } from './app.mjs';
import { OfficialWallet, createCliRunner } from './official-cli.mjs';
import { walletChildEnvironment } from './cli-network.mjs';
const network = await walletChildEnvironment({ enabled: true });
// User-selected local direct access. Do not load or create any owner/password configuration.
const app = await createApplication({ sessions: new Sessions(), wallet: new OfficialWallet(createCliRunner({ childEnv: network.env })), localAccess: true, walletAccess: true, port: 51769 });
console.log(`Agentic Wallet 开发看板：${app.origin}`);
console.log('本机直开，无需看板登录。官方钱包连接与只读报价可用；真实提交仍锁定。Ctrl+C 停止。');
console.log('CLI network mode: ' + network.mode);
for (const signal of ['SIGINT', 'SIGTERM']) process.once(signal, async () => { await app.close(); process.exit(0); });
