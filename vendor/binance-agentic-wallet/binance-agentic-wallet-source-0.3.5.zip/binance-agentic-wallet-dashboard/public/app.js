const $ = id => document.getElementById(id);
let snapshot = null, generation = 0, activeTab = 'assets', refreshing = false;
const errors = { TOKEN_PAIR_NOT_IN_DEMO: '本网络没有这组模拟代币，不能生成审阅。', LIMIT_CHAIN_UNSUPPORTED: '官方限价单仅支持 BSC 与 Solana。', INVALID_AMOUNT: '请填写有效的十进制数量和滑点。', INVALID_SLIPPAGE: '滑点必须在 0–100% 范围内。', LOCAL_ACCESS_DEMO_ONLY: '本机直开模式仅提供模拟功能，真实操作禁用。' };
function node(tag, content, cls) { const el = document.createElement(tag); if (content !== undefined) el.textContent = String(content); if (cls) el.className = cls; return el; }
async function api(path, body) {
  const res = await fetch(path, { method: body === undefined ? 'GET' : 'POST', credentials: 'omit', cache: 'no-store',
    headers: body === undefined ? {} : { 'Content-Type': 'application/json' },
    body: body === undefined ? undefined : JSON.stringify(body) });
  const data = await res.json();
  if (!res.ok) throw new Error(errors[data.error] || '请求被拒绝：' + data.error);
  return data;
}
function clearView(message = '正在加载本地工作台…') {
  generation++; snapshot = null;
  $('dashboard').hidden = true; $('loading-view').hidden = false;
  $('access-badge').textContent = '等待连接'; $('access-message').textContent = message;
  $('loading-message').textContent = message;
  for (const id of ['data-table', 'wallet-addresses', 'review-details', 'review-blockers']) $(id).replaceChildren();
  for (const id of ['known-value', 'unpriced-count', 'network-count']) $(id).textContent = '—';
  for (const id of ['from-token', 'to-token']) $(id).replaceChildren();
  $('from-contract').textContent = ''; $('to-contract').textContent = ''; $('contract-filter').value = '';
  $('amount').value = ''; $('slippage').value = ''; $('trigger-price').value = ''; $('review-ack').textContent = '';
  if ($('review-dialog').open) $('review-dialog').close();
}
async function loadWorkspace() {
  if (refreshing) return; refreshing = true; clearView();
  const current = generation; $('refresh-button').disabled = true;
  try {
    const state = await api('/api/status');
    if (state.accessMode !== 'local' || state.loginRequired !== false) throw new Error('请启动当前版本的本机直开服务。');
    const data = await api('/api/demo'); if (current !== generation) return;
    snapshot = data; $('dashboard').hidden = false; $('loading-view').hidden = true;
    $('access-badge').textContent = '已就绪'; $('access-message').textContent = '无需看板密码。真实钱包须由你在 Binance App 单独授权。';
    fillOptions($('network-filter'), [{ id: 'all', name: '全部模拟网络' }, ...data.chains]);
    fillOptions($('trade-chain'), data.chains); $('amount').value = '0.1'; renderData(); fillTokens();
  } catch (error) { if (current === generation) clearView('暂时无法加载本机数据。请点击“刷新模拟数据”重试。' + (error.message || '')); }
  finally { refreshing = false; $('refresh-button').disabled = false; }
}
function fillOptions(el, data) { el.replaceChildren(...data.map(x => { const o = node('option', x.name); o.value = x.id; return o; })); }
function chainName(id) { return snapshot?.chains.find(c => c.id === id)?.name || id; }
function money(value) { return value == null ? '暂无估值' : '$' + Number(value).toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 }); }
function matchesContract(a, b, chain) { return chain === 'CT_501' ? a === b : a.toLowerCase() === b.toLowerCase(); }
function stateLabel(state) { return ({ confirmed: '链上确认样例', pending: '待处理样例', WORKING: '等待触发样例', PENDING: '处理中样例', UNKNOWN: '结果未知' })[state] || '状态未确认'; }
function table(headers, rows) {
  const t = node('table'), head = node('thead'), tr = node('tr'); headers.forEach(h => tr.append(node('th', h))); head.append(tr); t.append(head);
  const body = node('tbody'); for (const cells of rows) { const row = node('tr'); for (const value of cells) { const td = node('td'); td.append(value instanceof Node ? value : node('span', value)); row.append(td); } body.append(row); } t.append(body);
  if (!rows.length) { const row = node('tr'), td = node('td', '当前筛选没有模拟记录；不代表真实余额或授权为零。', 'empty'); td.colSpan = headers.length; body.append(row); }
  $('data-table').replaceChildren(t);
}
function renderData() {
  if (!snapshot) return;
  const network = $('network-filter').value, contract = $('contract-filter').value.trim();
  const inNetwork = x => network === 'all' || x.chainId === network;
  const rows = snapshot.assets.filter(inNetwork).filter(x => !contract || matchesContract(x.contract, contract, x.chainId));
  // Fixture amounts only: real estimates are calculated as decimal BigInts by the backend.
  const known = rows.reduce((sum, x) => sum + Number(x.valueUsd || 0), 0);
  $('known-value').textContent = money(known); $('unpriced-count').textContent = rows.filter(x => x.valueUsd === null).length + ' 项';
  $('network-count').textContent = new Set(rows.map(x => x.chainId)).size + ' 个';
  $('wallet-addresses').replaceChildren(...snapshot.chains.filter(x => network === 'all' || x.id === network).map(c => {
    const line = node('div'); line.append(node('span', c.name, 'small muted'), node('code', snapshot.wallets[c.id] + ' · 模拟占位地址')); return line;
  }));
  $('contract-filter').disabled = activeTab !== 'assets';
  $('table-caption').textContent = activeTab === 'assets' ? '模拟价格来源：内置快照 / 2026-10-22' : '仅演示状态，不是你的交易记录';
  if (activeTab === 'assets') table(['资产 / 网络', '数量', '估值 · USD', '合约 / 原生币标记'], rows.map(x => {
    const name = node('div'); name.append(node('b', x.symbol), node('small', chainName(x.chainId)));
    const c = node('div'); c.append(node('code', x.contract, 'contract'), node('small', x.native ? '原生币；此值为接口标记' : '按网络 + 完整合约区分'));
    return [name, x.balance, money(x.valueUsd), c];
  }));
  if (['history', 'pending'].includes(activeTab)) table(['网络', '记录', '状态', '时间', '交易哈希'], snapshot.transactions.filter(inNetwork).filter(x => activeTab !== 'pending' || x.status === 'pending').map(x => [chainName(x.chainId), x.id, stateLabel(x.status), x.time, '无真实哈希 · 模拟']));
  if (activeTab === 'orders') table(['网络', '订单', '类型', '状态', '支付数量'], snapshot.orders.filter(inNetwork).map(x => [chainName(x.chainId), x.id, x.type, stateLabel(x.status), x.amount]));
  if (activeTab === 'approvals') {
    const box = node('div', undefined, 'empty'); box.append(node('p', '未读取真实代币授权'), node('p', '官方支持 EVM 授权查询与撤销。Solana 不适用此 EVM 接口。', 'small'), node('p', '撤销交易广播后仍须等待链上确认。关闭页面不会自动撤销。', 'small'));
    const button = node('button', '撤销代币授权 · 开发期禁用'); button.disabled = true; box.append(button); $('data-table').replaceChildren(box);
  }
}
function fillTokens() {
  if (!snapshot) return;
  const chain = $('trade-chain').value, tokens = snapshot.assets.filter(x => x.chainId === chain);
  for (const id of ['from-token', 'to-token']) fillOptions($(id), tokens.map(x => ({ id: x.contract, name: x.symbol + (x.native ? ' · 原生币' : '') })));
  if (tokens.length > 1) $('to-token').selectedIndex = 1;
  $('review-button').disabled = tokens.length < 2 || ($('trade-kind').value === 'limit' && !['56', 'CT_501'].includes(chain));
  $('quote-message').textContent = tokens.length < 2 ? '此网络仅有一个模拟资产，无法生成兑换审阅；没有使用其他网络替代。' : '真实提交锁定：交易总 Gas、费用、价格影响及授权方案尚不完整。';
  updateContracts();
}
function updateContracts() { $('from-contract').textContent = $('from-token').value; $('to-contract').textContent = $('to-token').value; }
$('refresh-button').onclick = loadWorkspace;
$('network-filter').onchange = renderData; $('contract-filter').oninput = renderData;
$('trade-chain').onchange = fillTokens; $('from-token').onchange = updateContracts; $('to-token').onchange = updateContracts;
$('trade-kind').onchange = () => { $('limit-fields').hidden = $('trade-kind').value !== 'limit'; fillTokens(); };
document.querySelectorAll('[data-tab]').forEach(button => button.onclick = () => { activeTab = button.dataset.tab; document.querySelectorAll('[data-tab]').forEach(b => b.setAttribute('aria-selected', String(b === button))); renderData(); });
document.querySelectorAll('[data-page]').forEach(button => button.onclick = () => { $('workspace-page').hidden = button.dataset.page !== 'workspace'; $('research-page').hidden = button.dataset.page !== 'research'; document.querySelectorAll('[data-page]').forEach(b => { if (b === button) b.setAttribute('aria-current', 'page'); else b.removeAttribute('aria-current'); }); });
$('quote-form').onsubmit = async e => {
  e.preventDefault(); if (!snapshot) return; const current = generation; $('review-button').disabled = true;
  try {
    const kind = $('trade-kind').value, trigger = $('trigger-price').value;
    if (kind === 'limit' && (!/^\d+(\.\d+)?$/.test(trigger) || Number(trigger) <= 0)) throw new Error('请明确填写模拟限价触发价格。');
    const q = await api('/api/demo/quote', { chainId: $('trade-chain').value, fromToken: $('from-token').value, toToken: $('to-token').value, amount: $('amount').value, slippage: $('slippage').value, kind });
    if (current !== generation || !snapshot) return;
    const details = [['网络', chainName(q.chainId) + ' / ' + q.chainId], ['钱包', q.wallet + '（非真实地址）'], ['订单类型', kind === 'limit' ? '限价草稿' : '即时兑换草稿'], ['支付合约 / 标记', q.fromToken], ['接收合约 / 标记', q.toToken], ['支付数量', q.amount + ' ' + q.fromSymbol], ['预计到账（模拟）', q.estimatedOut === null ? (kind === 'limit' ? '待触发时确定；不是当前兑换报价' : '暂无估值') : q.estimatedOut + ' ' + q.toSymbol], ['滑点上限', q.slippagePercent + '%'], ['价格影响', '未确认'], ['交易总 Gas', '未确认，不能按零处理'], ['已知费用', '未确认，不能按零处理'], ['代币授权', 'spender / 额度 / 期限未确认']];
    if (kind === 'limit') details.splice(3, 0, ['触发价格（模拟）', '$' + trigger]);
    $('review-details').replaceChildren(...details.map(([k, v]) => { const d = node('div'); d.append(node('dt', k), node('dd', v)); return d; }));
    $('review-blockers').replaceChildren(...q.blockers.map(x => node('li', x))); $('review-ack').textContent = ''; $('review-dialog').showModal();
  } catch (err) { if (current === generation) $('quote-message').textContent = err.message; } finally { if (current === generation) $('review-button').disabled = false; }
};
$('close-review').onclick = () => $('review-dialog').close(); $('ack-review').onclick = () => { $('review-ack').textContent = '已核对模拟草稿。未进行钱包授权、签名或订单提交。'; };
window.addEventListener('offline', () => clearView('连接中断，请点击“刷新模拟数据”重试。'));
window.addEventListener('online', loadWorkspace);
window.addEventListener('pageshow', e => { if (e.persisted) loadWorkspace(); });
async function research() {
  const res = await fetch('/research.json', { cache: 'no-store' }), data = await res.json();
  const tableEl = node('table'), head = node('tr'); ['能力', '官方支持 / 限制', '本版本状态', '依据'].forEach(x => head.append(node('th', x))); const th = node('thead'); th.append(head); tableEl.append(th);
  const body = node('tbody'); for (const item of data.capabilities) { const row = node('tr'); row.append(node('td', item.name), node('td', item.official), node('td', item.implementation)); const td = node('td'); item.sources.forEach(index => { const source = data.sources[index], a = node('a', source.title); a.href = source.url; a.target = '_blank'; a.rel = 'noopener noreferrer'; td.append(a, node('br')); }); row.append(td); body.append(row); } tableEl.append(body); $('research-table').replaceChildren(tableEl);
  $('source-list').replaceChildren(...data.sources.map(s => { const a = node('a', s.title + ' ↗'); a.href = s.url; a.target = '_blank'; a.rel = 'noopener noreferrer'; return a; }));
}
research().catch(() => { $('research-table').textContent = '资料未能加载，请查看项目内的官方核查报告。'; });
await loadWorkspace();
