import { PHASES, STAGES, activePhases, diagnosticText, safeDiagnosticExport } from './connection-state.js';
import { AUTH_URL_ISSUES } from './official-error-catalog.js';
const $ = id => document.getElementById(id);
let token = null, state = null, epoch = 0, pollTimer, expiryTimer, pollBusy = false, readVersion = 0;
let connectBusy = false, pollController = null, lastDiagnostic = null, cooldownTimer;
let cliVersions = {};
const messages = {
  LOCAL_SESSION_EXPIRED: '本页连接已过期或已在另一页面重新打开。请重新连接。',
  WALLET_NOT_BOUND: '请先在 Binance App 核对钱包地址并绑定。',
  WALLET_AUTH_INVALID: '官方钱包尚未连接或授权已失效，请重新连接。',
  WALLET_AUTH_EXPIRED: '官方钱包授权已过期，请重新连接。',
  WALLET_IDENTITY_MISMATCH: '钱包地址发生变化，已锁定。请重新核对地址。',
  AUTH_IN_PROGRESS: '官方验证正在进行，请等待完成或超时后重试。',
  AUTH_RATE_LIMIT: '请稍等片刻再生成新的配对码。',
  OFFICIAL_CLI_FAILED_OR_TIMED_OUT: '官方 CLI 请求失败或超时。未提交交易；请检查网络后重试。',
  OFFICIAL_WALLET_REQUEST_FAILED: '官方 CLI 未返回成功结果。未提交交易。',
  INVALID_AMOUNT: '数量必须为正十进制数；滑点须明确填写。',
  INVALID_CONTRACT: '请填写该网络的完整有效合约地址。',
  INVALID_SLIPPAGE: '滑点必须在 0–100% 范围内。',
  LIMIT_CHAIN_UNSUPPORTED: '官方限价挂单查询仅支持 BSC / Solana。',
  APPROVALS_EVM_ONLY: '此授权查询仅适用于 EVM 网络。'
};
const el = (tag, text) => { const n = document.createElement(tag); if (text !== undefined) n.textContent = String(text); return n; };
async function api(path, body = {}, signal) {
  let response, data;
  try { response = await fetch(path, { method: 'POST', credentials: 'omit', cache: 'no-store', signal,
    headers: { 'Content-Type': 'application/json', ...(token ? { 'X-Local-Session': token } : {}) }, body: JSON.stringify(body) }); }
  catch (error) {
    if (error.name === 'AbortError') throw error;
    lastDiagnostic = { code: 'LOCAL_SERVICE_UNAVAILABLE', category: 'LOCAL_HTTP', stage: 'HTTP', at: new Date().toISOString() };
    throw Error('无法连接本机接口；具体原因未确认。先检查本地服务是否运行，不代表官方授权已取消。');
  }
  try { data = await response.json(); }
  catch { lastDiagnostic = { code: 'LOCAL_RESPONSE_PARSE_FAILED', category: 'PARSE', stage: 'HTTP', at: new Date().toISOString() }; throw Error('本机接口返回格式异常，未能核对授权状态。'); }
  if (!response.ok) {
    lastDiagnostic = data.diagnostic || { code: 'INTERNAL_ERROR', category: 'LOCAL_FLOW', stage: 'LOCAL' };
    const message = describeDiagnostic(data.diagnostic) || messages[data.error] || '本机请求被拒绝，原因未确认。';
    if (response.status === 401 || ['WALLET_AUTH_INVALID', 'WALLET_AUTH_EXPIRED', 'WALLET_IDENTITY_MISMATCH', 'WALLET_BINDING_CHANGED'].includes(data.error)) wipe(message);
    throw Error(message);
  }
  return data;
}
function describeDiagnostic(d) {
  if (!d) return '';
  const safe = safeDiagnosticExport(d);
  const identity = [safe.officialName, safe.officialCode !== undefined ? String(safe.officialCode) : null].filter(Boolean).join(' / ');
  const signals = [...(safe.connectionSignals || []), ...(safe.httpStatus ? ['HTTP ' + safe.httpStatus] : [])].join(', ');
  const urlIssues = safe.authUrlIssues?.map(x => AUTH_URL_ISSUES[x]).join('、');
  return `${STAGES[d.stage] || '本地流程'}：${d.message || '请求失败。'}${identity ? ' 官方错误：' + identity + '。' : ''}${signals ? ' 返回的连接标识：' + signals + '。' : ''}${urlIssues ? ' 拦截原因：' + urlIssues + '。' : ''} ${d.nextStep || ''}`;
}
function connectionControls(v, message) {
  clearTimeout(cooldownTimer);
  const phase = v?.phase || 'DISCONNECTED', active = activePhases.includes(phase);
  const remaining = phase === 'DISCONNECTED' && Number.isSafeInteger(v?.nextSignInAt) ? Math.max(0, v.nextSignInAt - Date.now()) : 0;
  for (const name of ['wallet-badge', 'top-wallet-state']) $(name).textContent = PHASES[phase] || PHASES.DISCONNECTED;
  for (const name of ['connect-wallet', 'top-connect-wallet']) {
    $(name).disabled = connectBusy || active || phase === 'CONNECTED' || remaining > 0;
    $(name).textContent = remaining > 0 ? `连接冷却中（${Math.ceil(remaining / 1000)} 秒）` : phase === 'REVIEW' ? '核对钱包地址' : ['FAILED', 'TIMEOUT', 'PAUSED'].includes(phase) || v?.requiresStatusCheck ? '核对状态后重试' : '连接 Agentic Wallet';
  }
  if (remaining > 0) cooldownTimer = setTimeout(() => connectionControls(v, message), Math.min(1000, remaining));
  $('top-wallet-message').textContent = message || '';
  $('wallet-message').textContent = message || '';
  const expired = Number.isFinite(Number(v?.authExpiresAt)) && Number(v.authExpiresAt) <= Date.now();
  const showAuth = phase === 'WAITING' && !!v?.urlForWeb && !expired;
  for (const name of ['wallet-auth', 'top-wallet-auth']) $(name).hidden = !showAuth;
  for (const name of ['pairing-code', 'top-pairing-code']) $(name).textContent = showAuth ? v.pairingCode || '' : '';
  for (const name of ['official-auth-link', 'top-official-auth-link']) {
    if (showAuth) $(name).href = v.urlForWeb; else $(name).removeAttribute('href');
  }
  $('stop-wallet-wait').hidden = !active; $('stop-wallet-wait').disabled = v?.stage === 'BIND';
  if (expired && phase === 'WAITING') $('top-wallet-message').textContent = '配对码已到期，核验仍待官方返回。可停止本页等待后核对状态；不表示远端授权已撤销。';
}
function showFailure(message) {
  if (state?.walletConnected) void lock(message);
  clearTimeout(pollTimer); pollController?.abort();
  clearPrivateData(); $('wallet-candidate').hidden = true;
  for (const name of ['bind-wallet', 'read-wallet', 'live-chain', 'live-quote-button']) $(name).disabled = true;
  state = { ...state, walletConnected: false, phase: lastDiagnostic?.category === 'TIMEOUT' ? 'TIMEOUT' : 'FAILED', stage: lastDiagnostic?.stage || 'LOCAL', diagnostic: lastDiagnostic, requiresStatusCheck: true };
  connectionControls(state, message);
}
function clearPrivateData() {
  readVersion++; $('live-table').replaceChildren(); $('live-review-details').replaceChildren(); $('live-review-blockers').replaceChildren();
  if ($('live-review').open) $('live-review').close();
  $('candidate-addresses').replaceChildren(); $('live-address').textContent = '尚未绑定钱包地址';
}
function wipe(message = '本页已断开。未撤单、未撤销链上授权；官方 CLI 状态未改变。') {
  epoch++; token = null; state = null; connectBusy = false; clearTimeout(pollTimer); clearTimeout(expiryTimer); pollController?.abort(); clearPrivateData();
  $('wallet-auth').hidden = true; $('pairing-code').textContent = ''; $('official-auth-link').removeAttribute('href');
  $('wallet-candidate').hidden = true; $('wallet-badge').textContent = '未连接'; $('read-permission').textContent = '未授权';
  $('wallet-notice').textContent = '钱包未连接'; $('live-data-badge').textContent = '未连接';
  $('wallet-message').textContent = message; $('global-state').textContent = '本机直开 · 钱包未连接';
  $('connect-wallet').disabled = false; $('confirm-wallet-address').checked = false;
  for (const name of ['lock-wallet', 'signout-wallet', 'bind-wallet', 'read-wallet', 'live-chain', 'live-quote-button']) $(name).disabled = true;
  $('live-chain').replaceChildren(el('option', '连接后加载网络'));
  for (const name of ['live-contract', 'live-from', 'live-to', 'live-amount', 'live-slippage']) $(name).value = '';
  $('live-quote-message').textContent = '请先连接并核对钱包。'; $('live-read-message').textContent = '真实账户信息已清除。';
  connectionControls({ phase: 'DISCONNECTED' }, message);
}
async function session() {
  if (!token) {
    const current = epoch, v = await api('/api/local/session');
    if (current !== epoch) throw Error('本页连接请求已取消。');
    token = v.token;
  }
}
function render(v) {
  const wasConnected = !!state?.walletConnected; state = v;
  clearTimeout(expiryTimer);
  expiryTimer = setTimeout(() => lock('本页连接或官方授权到期。'), Math.max(0, Math.min(v.expiresAt, v.walletExpiresAt || Infinity) - Date.now()));
  const connected = v.walletConnected;
  $('lock-wallet').disabled = false; $('signout-wallet').disabled = !connected;
  $('wallet-candidate').hidden = v.phase !== 'REVIEW';
  if (v.phase === 'REVIEW') {
    $('candidate-note').textContent = v.alreadyConnected ? '官方 CLI 已有登录。已有连接不能证明它是你的目标钱包；请在 App 核对每个地址后确认。' : '官方状态已验证 CONNECTED。请核对下列完整地址；绑定只授予本页查询权限。';
    $('candidate-addresses').replaceChildren(...v.addresses.map(a => { const div = el('div'); div.append(el('span', v.chains.find(c => c.id === a.chainId)?.name || a.chainId), el('code', a.address)); return div; }));
    $('bind-wallet').disabled = !$('confirm-wallet-address').checked;
  } else $('candidate-addresses').replaceChildren();
  if (v.diagnostic) lastDiagnostic = v.diagnostic;
  const message = connected ? '官方状态与钱包地址核验完成；只开放读取和报价。' : v.diagnostic ? describeDiagnostic(v.diagnostic)
    : v.phase === 'WAITING' ? '请主动打开官方授权页面，在 Binance App 核对配对码。官方核验最多等待 5 分钟。'
    : v.phase === 'REVIEW' ? '官方已连接；仍需本人核对完整地址，尚未启用账户查询。'
    : v.phase === 'PAUSED' ? '已停止本页等待和轮询，未撤销远端授权。前一次核验结束后请核对官方状态。'
    : v.phase === 'STARTING' ? '正在请求官方授权链接；本地等待上限 25 秒（不是官方承诺时限）。'
    : activePhases.includes(v.phase) ? `正在${STAGES[v.stage] || '核验'}；请勿重复发起。`
    : '官方状态未确认已连接。点击连接前会再次核对官方状态。';
  connectionControls(v, message);
  $('read-permission').textContent = connected ? '已绑定 · 逐次核验' : '未授权';
  $('wallet-notice').textContent = connected ? '真实钱包已绑定 · 交易提交锁定' : '钱包未绑定 · 尚未读取资产';
  $('global-state').textContent = connected ? '真实钱包 · Swap 报价可用' : '本机直开 · 钱包待连接';
  for (const name of ['live-chain', 'read-wallet', 'live-quote-button']) $(name).disabled = !connected;
  if (connected && !wasConnected) {
    $('live-chain').replaceChildren(...v.chains.map(c => { const o = el('option', c.name + ' / ' + c.id); o.value = c.id; return o; }));
    if (v.chains.some(c => c.id === '56')) $('live-chain').value = '56';
    changeChain(); $('live-data-badge').textContent = '已绑定 · 待查询';
  }
  if (connected) $('live-quote-message').textContent = '可查询官方报价；获取报价不会发起购买。';
  clearTimeout(pollTimer);
  if (!['FAILED', 'TIMEOUT', 'PAUSED', 'DISCONNECTED'].includes(v.phase)) pollTimer = setTimeout(poll, connected ? 20_000 : 1500);
}
async function poll() {
  if (!token || pollBusy) return; const current = epoch; pollBusy = true;
  const controller = new AbortController(); pollController = controller;
  try { const v = await api('/api/local/state', {}, controller.signal); if (current === epoch && !controller.signal.aborted) render(v); }
  catch (error) { if (current === epoch && error.name !== 'AbortError') { clearPrivateData(); showFailure(error.message); } }
  finally { pollBusy = false; }
}
async function lock(message) {
  const previous = token; wipe(message);
  if (previous) try { await fetch('/api/local/lock', { method: 'POST', credentials: 'omit', keepalive: true,
    headers: { 'Content-Type': 'application/json', 'X-Local-Session': previous }, body: '{}' }); } catch { /* local proof is gone; backend expires independently */ }
}
function changeChain() {
  readVersion++; $('live-table').replaceChildren(); $('live-contract').value = '';
  if ($('live-review').open) $('live-review').close();
  const chain = $('live-chain').value, address = state?.addresses?.find(a => a.chainId === chain)?.address;
  $('live-address').textContent = address || '地址未核验';
  // Official Common Token Addresses table, BSC only. Other chains require explicit contracts.
  $('live-from').value = chain === '56' ? '0xEeeeeEeeeEeEeeEeEeEeeEEEeeeeEeeeeeeeEEeE' : '';
  $('live-to').value = chain === '56' ? '0x55d398326f99059fF775485246999027B3197955' : '';
  $('live-read-message').textContent = '已选择网络，点击查询获取该钱包的真实数据。';
}
function table(headers, rows) {
  const t = el('table'), head = el('tr'), thead = el('thead'), body = el('tbody');
  headers.forEach(x => head.append(el('th', x))); thead.append(head); t.append(thead, body);
  rows.forEach(row => { const tr = el('tr'); row.forEach(x => tr.append(el('td', x ?? '未返回'))); body.append(tr); });
  if (!rows.length) { const tr = el('tr'), td = el('td', '官方未返回记录；不据此断言余额或授权为零。'); td.colSpan = headers.length; tr.append(td); body.append(tr); }
  $('live-table').replaceChildren(t);
}
const statusLabel = s => ({ PENDING: '处理中，尚未成交', FINISHED: '官方报告执行成功', FAILED: '失败', WORKING: '等待触发', TRIGGERED: '已触发', confirmed: '链上已确认', pending: '待处理', CANCELED: '已取消', EXPIRED: '已过期' })[s] || '状态未确认';
async function connectWallet() {
  if (connectBusy || activePhases.includes(state?.phase) || state?.walletConnected) return;
  if (state?.phase === 'REVIEW') { document.querySelector('[data-page="workspace"]').click(); $('wallet-candidate').scrollIntoView({ block: 'center' }); return; }
  const checkOnly = ['FAILED', 'TIMEOUT', 'PAUSED'].includes(state?.phase) || state?.requiresStatusCheck;
  const current = epoch; connectBusy = true;
  state = { ...state, phase: 'CHECKING', stage: 'STATUS', diagnostic: null };
  connectionControls(state, '正在核对连接状态；不会重复创建授权请求。');
  try {
    await session(); if (current !== epoch) return;
    const v = await api(checkOnly ? '/api/wallet/check' : '/api/wallet/signin'); if (current !== epoch) return;
    connectBusy = false; render(v);
  } catch (error) { if (current === epoch) { connectBusy = false; showFailure(error.message); } }
  finally { connectBusy = false; }
}
$('connect-wallet').onclick = connectWallet; $('top-connect-wallet').onclick = connectWallet;
$('stop-wallet-wait').onclick = async () => {
  clearTimeout(pollTimer); pollController?.abort(); const current = ++epoch; connectBusy = false;
  state = { ...state, phase: 'PAUSED', stage: 'LOCAL', diagnostic: null, requiresStatusCheck: true }; connectionControls(state, '正在停止本页等待；未撤销远端授权。');
  try { const v = await api('/api/wallet/stop-waiting'); if (current === epoch) render(v); }
  catch (error) { if (current === epoch) showFailure(error.message); }
};
$('copy-wallet-diagnostic').onclick = async () => {
  const value = diagnosticText(state, lastDiagnostic, document.body.dataset.qa === 'true', cliVersions);
  try { await navigator.clipboard.writeText(value); $('diagnostic-copy-message').textContent = lastDiagnostic && state?.diagnostic !== lastDiagnostic
    ? '已复制脱敏诊断；错误记录已标记为上一次失败，与当前状态分开。'
    : '已复制脱敏诊断，不含地址、配对码或授权链接。'; $('diagnostic-fallback').hidden = true; }
  catch { $('diagnostic-fallback').hidden = false; $('diagnostic-fallback').value = value; $('diagnostic-fallback').select(); $('diagnostic-copy-message').textContent = '剪贴板不可用，请手动复制下方脱敏诊断。'; }
};
$('confirm-wallet-address').onchange = () => { $('bind-wallet').disabled = !$('confirm-wallet-address').checked; };
$('bind-wallet').onclick = async () => {
  const current = epoch; $('bind-wallet').disabled = true;
  state = { ...state, phase: 'VERIFYING', stage: 'BIND', diagnostic: null };
  connectionControls(state, '正在重新核对官方状态和钱包身份，尚未显示连接成功。');
  try { const v = await api('/api/wallet/bind', { candidateId: state.candidateId, confirmed: $('confirm-wallet-address').checked }); if (current === epoch) render(v); }
  catch (error) { if (current === epoch) showFailure(error.message); }
};
$('lock-wallet').onclick = () => lock();
$('signout-wallet').onclick = async () => {
  if (!confirm('退出官方 CLI 会清除其本地会话，可能影响使用同一 CLI 的工具。不会撤销链上代币授权、撤单或平仓。确认退出？')) return;
  $('signout-wallet').disabled = true; const current = epoch;
  try { const v = await api('/api/wallet/signout', { confirmed: true }); if (current === epoch) wipe(v.localSessionCleared ? '官方 CLI 已确认退出。未撤单，也未撤销链上授权。' : '本页已断开，官方 CLI 退出状态未确认。请到官方 App 检查。'); }
  catch { if (current === epoch) wipe('本页已断开，官方 CLI 退出状态未确认。请到官方 App 检查。'); }
};
$('live-chain').onchange = changeChain;
$('live-kind').onchange = () => { readVersion++; $('live-table').replaceChildren(); $('live-contract').disabled = $('live-kind').value !== 'assets'; };
$('read-wallet').onclick = async () => {
  const current = epoch, version = ++readVersion, kind = $('live-kind').value; $('read-wallet').disabled = true; $('live-table').replaceChildren();
  $('live-read-message').textContent = '正在核验钱包、授权期限并查询官方数据…';
  try {
    const body = { chainId: $('live-chain').value, kind }; if (kind === 'assets' && $('live-contract').value.trim()) body.contract = $('live-contract').value.trim();
    const v = await api('/api/wallet/read', body); if (current !== epoch || version !== readVersion) return;
    if (kind === 'assets') table(['代币', '完整合约 / 标记', '数量', '估值 USD', '盈亏'], v.assets.map(x => [x.symbol, x.contract, x.balance, x.valueUsd ?? '暂无估值', '成本不足，未计算']));
    else if (['transactions', 'pending'].includes(kind)) table(['类型', '状态', '时间', '交易哈希'], v.transactions.map(x => [x.type, statusLabel(x.status), x.time, x.txHash]));
    else if (kind === 'approvals') table(['代币', '合约', 'Spender', '授权数量'], v.map(x => [x.symbol, x.contract, x.spender, x.amount]));
    else table(['订单 ID', '状态', '支付合约', '接收合约', '支付数量', '交易哈希'], v.list.map(x => [x.orderId, statusLabel(x.status), x.fromToken, x.toToken, x.amount, x.txHash]));
    $('live-data-badge').textContent = '真实官方返回'; $('live-read-message').textContent = '来源：Binance Agentic Wallet CLI · ' + new Date().toLocaleString() + '。显示首批记录；不是完整账本。' + (v.coverage || '');
  } catch (error) { if (current === epoch && version === readVersion) $('live-read-message').textContent = error.message; }
  finally { if (current === epoch) $('read-wallet').disabled = !state?.walletConnected; }
};
$('live-quote-form').onsubmit = async event => {
  event.preventDefault(); const current = epoch, chainId = $('live-chain').value; $('live-quote-button').disabled = true;
  $('live-quote-message').textContent = '正在核验钱包并请求官方报价…';
  try {
    const q = await api('/api/wallet/quote', { chainId, fromToken: $('live-from').value.trim(), toToken: $('live-to').value.trim(), amount: $('live-amount').value.trim(), slippage: $('live-slippage').value.trim() });
    if (current !== epoch || chainId !== $('live-chain').value) return;
    const details = [['网络', q.chainId], ['钱包', q.wallet], ['支付合约 / 原生币标记', q.fromToken], ['接收合约', q.toToken], ['支付数量', q.amount + ' ' + (q.fromSymbol || '')], ['预计到账', q.estimatedOut === null ? '官方未返回' : q.estimatedOut + ' ' + (q.toSymbol || '')], ['滑点上限', q.slippagePercent + '%'], ['价格影响', '未确认'], ['总 Gas', '未确认'], ['逐笔费用', '未确认；官方费率说明不等于完整交易费用'], ['代币授权', 'Spender、额度及期限未确认'], ['提交状态', '未提交，没有订单 ID']];
    $('live-review-details').replaceChildren(...details.map(([k, v]) => { const div = el('div'); div.append(el('dt', k), el('dd', v)); return div; }));
    $('live-review-blockers').replaceChildren(...q.blockers.map(x => el('li', x))); $('live-review').showModal();
    $('live-quote-message').textContent = '官方报价已返回；未提交购买或代币授权。';
  } catch (error) { if (current === epoch) $('live-quote-message').textContent = error.message; }
  finally { if (current === epoch) $('live-quote-button').disabled = !state?.walletConnected; }
};
$('close-live-review').onclick = () => $('live-review').close();
$('show-demo').onclick = () => { document.body.classList.remove('wallet-mode'); };
$('show-live').onclick = () => { document.body.classList.add('wallet-mode'); };
window.addEventListener('offline', () => lock('网络中断，已断开本页并清除账户信息。'));
window.addEventListener('pagehide', () => lock());
window.addEventListener('pageshow', e => { if (e.persisted) wipe('页面已恢复，请重新连接并核对钱包。'); });
fetch('/api/status', { credentials: 'omit', cache: 'no-store' }).then(r => r.json()).then(v => {
  cliVersions = v.cli || {};
  $('installed-cli-version').textContent = cliVersions.installedVersion || '未确认';
  if (!v.capabilities?.liveWalletAuth) { connectionControls({ phase: 'DISCONNECTED' }, '本服务未启用钱包连接。'); $('top-connect-wallet').disabled = true; $('connect-wallet').disabled = true; }
}).catch(() => { $('installed-cli-version').textContent = '未确认'; });
