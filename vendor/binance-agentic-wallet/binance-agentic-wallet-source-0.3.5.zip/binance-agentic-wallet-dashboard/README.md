# Binance Agentic Wallet 本地看板

版本：0.3.5。此目录为可分享的源码快照，不含任何用户账户数据或登录状态。

## 运行

需要 Node.js 22+；Windows 系统代理兼容功能需要 Node.js 24+。依赖固定为官方 `@binance/agentic-wallet@1.11.0`，不代表最新版本或通用最低版本。

在本目录执行：

```sh
npm ci --ignore-scripts --no-audit --no-fund
npm test
npm start
```

打开 http://127.0.0.1:51769/ 。默认本机直开，无需看板密码；钱包连接、钱包地址确认与应用会话检查仍独立处理。旧密码配置脚本为历史功能，默认启动不需要运行。

## 当前功能与限制

- 包含资产工作台、官方接入核查、钱包连接流程、只读查询、兑换报价和脱敏诊断。
- 真实兑换提交、转账、链上授权变更、自动策略和无人值守交易保持禁用。
- 仅监听回环地址。本机其他进程或用户仍可能访问，不能视为面向公网的登录方案。
- 示例和自动化测试使用模拟数据。新环境不继承任何账户连接；官方 CLI 的登录成功也不等于本看板已完成地址核验和绑定。
- 当前看板仍严格校验授权地址示例范围；可能拒绝官方 CLI 实际返回的其他授权地址。此源码包保留该行为，未放宽白名单。
- README.txt 及其他核查、验收文档包含开发期间的历史记录；其中账户连接状态不代表下载者或当前运行环境的真实状态。

## 文件与隐私

包含 public/、server/、tests/、依赖锁文件及启动和历史密码配置脚本。排除 .private/、node_modules/、.env、日志、页面截图、授权链接和个人钱包地址。发布仅新增本说明及加强 .gitignore，不修改运行代码。

## 官方来源

- [安装与开通前提](https://developers.binance.com/en/docs/products/agentic-wallet/quickstart/install-agentic-wallet)
- [CLI 版本要求](https://github.com/binance/binance-skills-hub/blob/main/skills/binance-web3/binance-agentic-wallet/SKILL.md)
- [认证流程](https://github.com/binance/binance-skills-hub/blob/main/skills/binance-web3/binance-agentic-wallet/references/authentication.md)
- [钱包查询](https://github.com/binance/binance-skills-hub/blob/main/skills/binance-web3/binance-agentic-wallet/references/wallet-view.md)
